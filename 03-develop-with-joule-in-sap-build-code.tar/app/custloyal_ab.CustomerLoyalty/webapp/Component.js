sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("custloyalab.CustomerLoyalty.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);